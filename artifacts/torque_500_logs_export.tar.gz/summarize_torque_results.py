import json, re
from pathlib import Path
out = {}
for method in ["CTC", "SMC", "RBF_SMC"]:
    log = Path(f"/root/eval_torque_{method}_t50.log")
    text = log.read_text() if log.exists() else ""
    m = re.search(r"Total episodes:\s*(\d+).*?Total successes:\s*(\d+).*?Overall success rate:\s*([0-9.]+)", text, re.S)
    out[method] = {"episodes": int(m.group(1)), "successes": int(m.group(2)), "rate": float(m.group(3))} if m else {"error": "no final result"}
Path("/root/torque_core_summary.json").write_text(json.dumps(out, indent=2))
print(json.dumps(out, indent=2))
