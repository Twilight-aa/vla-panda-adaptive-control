from experiments.robot.libero.run_libero_eval import (
    GenerateConfig, initialize_model, setup_logging, get_image_resize_size,
    run_task, validate_config, set_seed_everywhere,
)
from libero.libero import benchmark

cfg = GenerateConfig(
    pretrained_checkpoint="/root/models/openvla-oft-libero-spatial",
    task_suite_name="libero_spatial",
    num_trials_per_task=1,
    use_wandb=False,
    center_crop=True,
    num_images_in_input=2,
    use_proprio=True,
    use_l1_regression=True,
    use_diffusion=False,
    use_film=False,
    load_in_8bit=False,
    load_in_4bit=False,
)
validate_config(cfg)
set_seed_everywhere(cfg.seed)
model, action_head, proprio_projector, noisy_action_projector, processor = initialize_model(cfg)
resize_size = get_image_resize_size(cfg)
log_file, local_log_filepath, run_id = setup_logging(cfg)
task_suite = benchmark.get_benchmark_dict()[cfg.task_suite_name]()
episodes, successes = run_task(
    cfg, task_suite, 0, model, resize_size, processor,
    action_head, proprio_projector, noisy_action_projector,
    0, 0, log_file,
)
print(f"SMOKE_RESULT episodes={episodes} successes={successes} run_id={run_id}")
if log_file:
    log_file.close()
