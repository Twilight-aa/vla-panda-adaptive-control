#!/bin/bash
set -o pipefail
source /root/miniconda3/etc/profile.d/conda.sh
conda activate openvla-oft
cd /root/openvla-oft
export MUJOCO_GL=egl
export PYOPENGL_PLATFORM=egl
export TOKENIZERS_PARALLELISM=false
export WANDB_MODE=offline
python experiments/robot/libero/run_libero_eval.py \
  --pretrained_checkpoint /root/models/openvla-oft-libero-spatial \
  --task_suite_name libero_spatial \
  --num_trials_per_task 50 \
  > /root/eval_spatial_t50.log 2>&1
rc=$?
echo "EXIT:$rc" >> /root/eval_spatial_t50.log
exit $rc
